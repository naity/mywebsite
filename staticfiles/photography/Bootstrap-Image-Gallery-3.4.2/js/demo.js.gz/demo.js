$(document).ready(function() {
  $('#blueimp-gallery').data('useBootstrapModal', false);
  $('#blueimp-gallery').toggleClass('blueimp-gallery-controls', true);
  $('#blueimp-gallery').data('fullScreen', true);
});